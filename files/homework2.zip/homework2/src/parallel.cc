// --*-c++-*--

#include <stdlib.h>
#include <mpi.h>

#include <iostream>
#include <string>

#include "image.h"
#include "image_utils.h"

std::string parallel_main(int argc, char* argv[])
{
  if (argc < 5) {
    std::cout << "usage: " << argv[0] << " "
	      << "<in image> <out image> <filter type> <window size>"
              << std::endl;
    std::cout << " filter type = {mean|median} " << std::endl;
    exit(-1);
  }

  int rank, namelen;
  char processor_name[MPI_MAX_PROCESSOR_NAME];

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Get_processor_name(processor_name, &namelen);

  std::string inFilename(argv[1]);
  std::string outFilename(argv[2]);
  std::string filterType(argv[3]);
  int windowSize = atoi(argv[4]);

  outFilename = "p_" + outFilename;

  Image input;
  if (rank == 0) {
    std::cout << "* doing parallel image filtering ** " << std::endl;
    std::cout << "* reading regular tiff: " << argv[1] << std::endl;
    input.load_tiff(std::string(argv[1]));
  }

  Image output = input;
  output.make_greyscale();

  std::cout << "[" << processor_name << "] processing with filter: " 
            << filterType << std::endl;

  if (filterType == "mean") {
    // begin parallel code
    // output.image_filter_mean(windowSize); 
    // end parallel code
  }
  else if (filterType == "median") {
    // begin parallel code
    // output.image_filter_median(windowSize);
    // end parallel code
  }

  if (rank == 0) {
    std::cout << "[" << processor_name << "] saving image: " 
              << outFilename 
              << std::endl;
    output.save_tiff_grey_8bit(outFilename);
  }

  std::cout << "-- done --" << std::endl;

  return outFilename;
}
