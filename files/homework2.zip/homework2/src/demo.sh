#!/bin/sh

./demo input/moon_in.tiff 4
